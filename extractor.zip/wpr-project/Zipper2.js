var zipFolder = require('zip-folder');
var fs = require('fs');

function zip(filepath){

    //This function can be used to zip any folder individually
    var newFilePath = filepath + ".zip";
    zipFolder(filepath, newFilePath, function(err) {
        if(err) {
            console.log(err);
        } else {
            console.log('Zipped successfully');
        }
    });
}

function zipF(filepath, callback){
    //This function takes a folder that has subfolders, zips each subfolder and the call a callback function that zip the main folder
    //It uses a callback because we want to make sure all subfolders are zipped before attempting to zip the main  
    
    
    //1. read the directory and zip all folders inside the directory
    fs.readdir(filepath, (err,folders) =>{
        if(err){
            console.log(err)
        }
        else{
            folders.forEach(path =>{
                zip(filepath + '/' + path);
                //remove the original folder after zipping
                fs.rmdir(filepath +'/'+ path,(e)=>{
                    if(e){
                        console.log(e);
                    }
                    else{
                        console.log("Deleted copy");
                    }
                });
            })
        }
    })
    
    //and finally zip the main folder, this process will wait for 10 seconds just to allow the functoin to finish zipping the subfolders
    setTimeout(() => {
        callback();
    }, 10000);
    
    
}

function zipAll(filepath){
    zipF(filepath,()=>{  //this line zips the subfoldres
        zip(filepath); //this is the callback that will zip the main folder after 10 seconds
        console.log("Zipped main folder");
    });
}

module.exports = {zipAll:zipAll};

//run this in App.js
