
const Zipper2 = require("./Zipper2");

//Zipper2.zipAll("mainfolder");

/*
    We need a menu that will enable a user to choose what operation they want to perform, e.g
        1. Zip
        2. Unzip
    
    Let's say we have a function Navigate() that allows a user to navigate to any path and returns that full path as a string
    our application would be something like this
*/
console.log('----------------------------------------------------------');
console.log('----------Welcome to the Amazing extracti-nator-----------');  
console.log('----------------------------------------------------------\n');
console.log('What do you wish to do?\n');
console.log('1. Compress Folder\n2. Extract Folder');
     

const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});
readline.question('\nEnter menu option\n', path => {
    console.log(`Chosen number is ${path}!`);
    var userOption = parseInt(path);
    readline.close();

    switch(userOption){
        case 1:
        // Zipper2.zipAll(Navigate()) //Since Navigate() returns a file path as a string, note that zipAll takes a path as a string
        console.log("\nYou have chosen to compress a folder\n") 
        const read = require('readline').createInterface({
                input: process.stdin,
                output: process.stdout
            });
            var s = '';
            read.question('\nEnter a directory path to compress\n ', path => {
                console.log(`Chosen path is ${path}!`);
                s = path;
                console.log(s)
                Zipper2.zipAll(s);
                read.close();         
            }); 
                             
            break;
        case 2:
            //Zipper2.unzipAll(Navigate()) 
            const line = require('readline').createInterface({
                input: process.stdin,
                output: process.stdout
            });
            var s = '';
            line.question('\nEnter a directory path to extract\n', path => {    
                console.log(`Chosen path is ${s}!`);                
                s = path;
                line.close();
                console.log(s)
                Zipper2.unzipAll(s);
            }); 
              
            break;
        default:
            console.log('Wrong menu option was given');
            break;
        }
});
  





 
 //C:\\Users\\27679\\Desktop\\BComp 3rd\\WPR381\\Assessments\\Projects\\wpr-project\\mainfolder
 /*




