/*
    This module will be deleted, it was the first attempt which didn't work very well.
    Please use Zipper2.js
*/

const fs = require("fs");
const zlib = require("zlib");
const compress = zlib.createGzip();
const decompress = zlib.createGunzip();


function zipFile(filepath){
    var readstream = fs.createReadStream(filepath);
    var newFile = filepath + ".zip"
    var writeStream = fs.createWriteStream(newFile);
    
    readstream.pipe(compress).pipe(writeStream);
}

function unzipFile(filepath){
    var readstream = fs.createReadStream(filepath);
    var newFile = filepath.replace(".zip","");
    var writeStream = fs.createWriteStream(newFile);
    
    readstream.pipe(decompress).pipe(writeStream);
}

function zipFolder(filepath){

    //read the directory and zip all folders inside the directory
    fs.readdir(filepath, (err,folders) =>{
        if(err){
            console.log(err)
        }
        else{
            folders.forEach(path =>{
                zipFile(path);
            })
        }
    })

    //and finally zip the main folder
    zipFile(filepath);

}

function unzipFolder(filepath){

    //unzip the main folder
    unzipFile(filepath);

    //unzip folders inside the unzipped main folder

    var newFilePath = filepath.replace(".zip","");
    fs.readdir(newFilePath, (err,folders) =>{
        if(err){
            console.log(err)
        }
        else{
            folders.forEach(path =>{
                unzipFile(path);
            })
        }
    })

    

}

module.exports = {zipFolder:zipFolder, unzipFolder:unzipFolder};